export class AadhaarInfo {

    constructor(public emailid:string,
        public aid:string,
        public name:string,
        public address:string,
        public mobileNo:string,
        public gender:string,
        public date:string,
        public status:string)
    {}

}
