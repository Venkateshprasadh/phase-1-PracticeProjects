import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  constructor(public service:UserServiceService,public router:Router) { }
  loginref= new FormGroup({username:new FormControl(),password:new FormControl()});

  ngOnInit(): void {
  }
  msg:string = '';
  login()
  {
    let val=this.loginref.value;
    console.log(val);
    let u:User=new User(val.username,val.password,"admin",0);

    if(val.username=="admin" && val.password=="admin")
    {
      this.router.navigate(['admindash'])
    }
    else{
      this.msg="only admin allowed"
    }
    
    }

  }

