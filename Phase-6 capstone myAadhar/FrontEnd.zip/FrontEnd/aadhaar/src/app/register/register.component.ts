import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerRef=new FormGroup({username:new FormControl(),password:new FormControl(),email:new FormControl(),phno:new FormControl()});

  constructor(public usrser:UserServiceService,public router:Router) { }
  msg:string = '';
  ngOnInit(): void {
  }


  register()
  {
    let reg=this.registerRef.value;
    let u:User = new User(reg.email,reg.password,"user",reg.phno);
    console.log(u);
    this.usrser.usrRegister(u).subscribe({
      next:(obj:any)=>{if(obj=="Registered")
                          {
                            this.router.navigate([""]);
                           }
                           else
                           {
                              this.msg=obj;
                           }
    },
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")});
  }

}
