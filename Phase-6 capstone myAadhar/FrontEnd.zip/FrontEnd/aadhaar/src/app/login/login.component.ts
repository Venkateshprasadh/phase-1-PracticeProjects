import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(public service:UserServiceService,public router:Router) { }

  loginref= new FormGroup({username:new FormControl(),password:new FormControl()});
  msg:string='';
  ngOnInit(): void {
  }

  login()
  {
    let val=this.loginref.value;
    console.log(val);
    let u:User=new User(val.username,val.password,"user",0);
    this.service.usrLogin(u).subscribe({
      next:(value)=>{
          console.log(value);
          if(value=="login")
          {
            sessionStorage.setItem("user",val.username);
            this.router.navigate(['userdash'])
          }
          else{
            this.msg=value;
          }
      },
      error:(err)=>console.log(err),
      complete:()=>console.log("complete")
    })

  }
}
