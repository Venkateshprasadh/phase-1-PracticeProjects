import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAadhaarComponent } from './view-aadhaar.component';

describe('ViewAadhaarComponent', () => {
  let component: ViewAadhaarComponent;
  let fixture: ComponentFixture<ViewAadhaarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewAadhaarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewAadhaarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
