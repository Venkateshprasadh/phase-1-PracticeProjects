import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-adminview',
  templateUrl: './adminview.component.html',
  styleUrls: ['./adminview.component.css']
})
export class AdminviewComponent implements OnInit {

  constructor(public usev:UserServiceService,router:Router) { }
  infos:any;
  msg:string="";
  
  ngOnInit(): void {
      this.usev.adminView().subscribe({
        next:(value)=>{
            console.log(value);
            this.infos=value;
        },
        error:(err)=>console.log(err),
        complete:()=>console.log("completed")
      })
  }

  delete(email:string)
  {
    
      this.usev.admindelete(email).subscribe({
        next:(value)=>{
            console.log(value);
            this.msg=value;
            window.alert(this.msg);
            
        },
        error:(err)=>console.log(err),
        complete:()=>console.log("completed")
      });
      window.location.reload();
  }

}
