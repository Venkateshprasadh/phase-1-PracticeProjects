import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AadhaarInfo } from '../aadhaar-info';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-apply-aadhaar',
  templateUrl: './apply-aadhaar.component.html',
  styleUrls: ['./apply-aadhaar.component.css']
})
export class ApplyAadhaarComponent implements OnInit {

  constructor(public ser:UserServiceService,public router:Router) { }
  user:string=""
  applyref=new FormGroup({email:new FormControl(),
    name: new FormControl(),
    mobileNo:new FormControl(),
    date:new FormControl(),
    address: new FormControl(),
    gender:new FormControl});

    msg:string="";

  ngOnInit(): void {
    let s=sessionStorage.getItem("user");
    if(s!=null){
      this.user=s;
      console.log(this.user)
    }
    else{
      console.log(s);
    }
  }
  
  apply()
  {
    let i=this.applyref.value
    let info= new AadhaarInfo(this.user,Date.now().toString(),i.name,i.address,i.mobileNo,i.gender,i.date,"pending")
    this.ser.usrApply(info).subscribe({
      next:(obj:any)=>{
      console.log(obj);
      this.msg=obj;},
      error:(err)=>console.log(err),
      complete:()=>console.log("completed")
    });
    
  }

}
