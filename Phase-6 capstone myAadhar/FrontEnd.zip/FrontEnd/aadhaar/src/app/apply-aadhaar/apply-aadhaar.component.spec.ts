import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplyAadhaarComponent } from './apply-aadhaar.component';

describe('ApplyAadhaarComponent', () => {
  let component: ApplyAadhaarComponent;
  let fixture: ComponentFixture<ApplyAadhaarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApplyAadhaarComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ApplyAadhaarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
