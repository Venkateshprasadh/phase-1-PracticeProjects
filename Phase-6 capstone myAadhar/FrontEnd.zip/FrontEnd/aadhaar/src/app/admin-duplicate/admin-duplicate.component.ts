import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-admin-duplicate',
  templateUrl: './admin-duplicate.component.html',
  styleUrls: ['./admin-duplicate.component.css']
})
export class AdminDuplicateComponent implements OnInit {

  constructor(public usev:UserServiceService,router:Router) { }
  infos:any;
  msg:string="";
  status:string="";
  ngOnInit(): void {
      this.usev.adminDuplicate().subscribe({
        next:(value)=>{
            console.log(value);
            this.infos=value;
        },
        error:(err)=>console.log(err),
        complete:()=>console.log("completed")
      })
  }

  update(email:string)
  {
    let i={emailid:email,status:this.status}
      this.usev.adminUpdate(i).subscribe({
        next:(value)=>{
            console.log(value);
            this.msg=value;
            window.alert(this.msg);
        },
        error:(err)=>console.log(err),
        complete:()=>console.log("completed")
      });
  }

}
